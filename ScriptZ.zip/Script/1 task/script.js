var name = prompt("Please, enter your name");
document.write(name);
