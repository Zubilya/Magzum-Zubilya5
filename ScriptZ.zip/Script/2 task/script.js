var year = prompt("Please enter year");
var week = prompt("Please enter weekday");
var date1 = prompt("Please enter date");
var month = prompt("Please enter month name");
var time = new Date();
var today = new Date();

document.write("Year is: " + year + "<br>");
document.write("Today is " + week + "<br>");
document.write("Date: " + date1 + "<br>");
document.write("Month: " + month + "<br>");
document.write("Current time is " + new Date().toLocaleTimeString('en-US', { hour: 'numeric', hour12: true, minute: 'numeric' }));
